import React from 'react'

const Event = () => {
  return (
    <div>event</div>
  )
}

export default Event