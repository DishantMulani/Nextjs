import React from 'react'

const AboutUsPage = () => {
    return (
        <>
            <h1>About Us Page</h1>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Explicabo mollitia nihil delectus reiciendis enim rem quis ratione, modi consequuntur eius! Similique voluptatem perferendis soluta, repellat laboriosam accusamus atque deserunt quisquam nobis distinctio. Qui ea aperiam ab, pariatur cupiditate autem cumque mollitia totam ducimus soluta, obcaecati at eius reiciendis vero consequuntur! Inventore repellat, odit, adipisci veritatis ullam neque error ut consequatur quasi repellendus quam possimus. Voluptate delectus voluptatem expedita obcaecati corrupti rem quod asperiores quasi dolores debitis culpa, excepturi minima magni consequatur maiores, voluptates distinctio porro possimus illo non nihil soluta eum laborum! Ipsam perspiciatis mollitia explicabo rerum eligendi ipsum rem.</p>
        </>
    )
}

export default AboutUsPage;